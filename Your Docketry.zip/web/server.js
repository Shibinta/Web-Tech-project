const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mongoose = require('mongoose');
const path = require('path');
const cookieParser = require('cookie-parser');
app.use(cookieParser());

app.use(express.static('public'));
// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Configure middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Connect to MongoDB database
mongoose.connect('mongodb://127.0.0.1:27017/users', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to the database successfully');
  })
  .catch((error) => {
    console.log('Error connecting to the database:', error.message);
  });

// Define user schema and model
const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  }
});
const User = mongoose.model('User', userSchema, 'users'); // Specify collection name as 'users'
const taskSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  task: {
    type: String,
    required: true
  },
  priority: {
    type: String,
    required: true
  }
});
const Task = mongoose.model('Task', taskSchema, 'tasks');


app.get('/', (req, res) => {
  const username = req.cookies.username;

  // If the username cookie is set, redirect to the home page
  if (username) {
    return res.redirect('/home.html');
  }

  // Otherwise, serve the login page
  res.sendFile(path.join(__dirname, 'login.html'));
});


app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Find the user in the database
    const user = await User.findOne({ username });

    // If the user doesn't exist or the password is incorrect, return an error
    if (!user || user.password !== password) {
      console.log('Request Payload:', req.body);
      console.log('Password entered:', password);
      console.log('Password stored in the database:', user ? user.password : null);
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Redirect to the home page with the username as a query parameter
    // Redirect to the home page with the username as a query parameter
  res.cookie('userId', user._id);
  res.redirect(`/home?username=${encodeURIComponent(username)}`);


  } catch (error) {
    res.status(500).json({ message: 'Error occurred while logging in' });
  }
});

app.get('/home', async (req, res) => {
  const username = req.query.username;

  // If the username is not provided in the query parameter, redirect to the login page
  if (!username) {
    return res.redirect('/');
  }

  try {
    // Find the user in the database
    const user = await User.findOne({ username });

    // If the user doesn't exist, return an error
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Fetch the tasks associated with the user
    const tasks = await Task.find({ user: user._id });

    // Render the home page with the tasks and username
    res.sendFile(path.join(__dirname, 'home.html'));


  } catch (error) {
    res.status(500).json({ message: 'Error occurred while fetching tasks' });
  }
});

app.get('/add.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'add.html'));
});

// ...

app.get('/addTask', async (req, res) => {
  const username = req.cookies.username;

  // If the username cookie is not set, redirect to the login page
  if (!username) {
    return res.redirect('/');
  }

  try {
    // Find the user in the database
    const user = await User.findOne({ username });

    // If the user doesn't exist, return an error
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Fetch the tasks associated with the user
    const tasks = await Task.find({ user: user._id });

    // Render the addTask page with the tasks and username
    res.sendFile(path.join(__dirname, 'add.html'));


  } catch (error) {
    res.status(500).json({ message: 'Error occurred while fetching tasks' });
  }
});
app.post('/addTask', async (req, res) => {
  const userId = req.cookies.userId;

  // If the userId cookie is not set, return an error
  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const { task, priority } = req.body;

  try {
    // Find the user in the database
    const user = await User.findById(userId);

    // If the user doesn't exist, return an error
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Create a new task with the user's ID, task, and priority
    const newTask = new Task({ user: user._id, task, priority });

    // Save the new task to the database
    const savedTask = await newTask.save();

    // Return the saved task as the response
    res.status(201).json({ task: savedTask });

  } catch (error) {
    console.error('Error occurred while creating task:', error.message); // Log the error message to the console
    res.status(500).json({ message: 'Error occurred while creating task' }); // Send the error message as a response
  }
});



// ...



app.get('/logout', (req, res) => {
  // Clear the username cookie
  res.clearCookie('username');

  // Redirect to the login page
  res.redirect('/');
});

// Start the server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});
