document.addEventListener('DOMContentLoaded', () => {
    const taskList = document.getElementById('task-list');
  
    // Function to add a task item to the list
    const addTaskToList = (task) => {
      const taskItem = document.createElement('li');
      taskItem.innerText = task.task;
      taskList.appendChild(taskItem);
    };
  
    // Function to clear the input fields
    const clearInputFields = () => {
      document.getElementById('task').value = '';
      document.getElementById('priority').value = '';
    };
  
    // Function to display an error message
    const displayError = (message) => {
      const errorContainer = document.getElementById('error-message');
      errorContainer.innerText = message;
    };
  
    // Function to display a success message
    const displaySuccess = (message) => {
      const successContainer = document.getElementById('success-message');
      successContainer.innerText = message;
    };
  
    // Fetch the tasks from the server and add them to the list
    fetch('/addTask')
      .then((response) => response.json())
      .then((data) => {
        const tasks = data.tasks;
        tasks.forEach((task) => {
          addTaskToList(task);
        });
      })
      .catch((error) => {
        displayError('Error occurred while fetching tasks');
        console.log('Error:', error);
      });
  
    // Handle the form submission
    const form = document.querySelector('form');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
  
      const taskInput = document.getElementById('task');
      const priorityInput = document.getElementById('priority');
  
      const task = taskInput.value;
      const priority = priorityInput.value;
      fetch('/getTasks') // Update the endpoint to the appropriate route
      .then((response) => response.json())
      .then((data) => {
        const tasks = data.tasks;
        tasks.forEach((task) => {
          addTaskToList(task);
        });
      })
      .catch((error) => {
        displayError('Error occurred while fetching tasks');
        console.log('Error:', error);
      });
      // Send the task and priority to the server
      fetch('/addTask', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ task, priority })
      })
        .then((response) => {
          if (response.ok) {
            displaySuccess('Task saved successfully!');
            return response.json();
          } else {
            displayError('Error occurred while saving the task');
            throw new Error('Task save request failed');
          }
        })
        .then((data) => {
          // Add the task to the list
          addTaskToList(data.task);
  
          // Clear the input fields
          clearInputFields();
        })
        .catch((error) => {
          console.log('Error:', error);
        });
    });
  });
  